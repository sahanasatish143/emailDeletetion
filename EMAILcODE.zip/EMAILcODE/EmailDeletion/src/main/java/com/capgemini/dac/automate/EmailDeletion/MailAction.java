/*
 * Copyright (c) 2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.EmailDeletion;

import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Properties;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;

import com.capgemini.dac.automate.Util.DateUtils;
import com.google.gson.JsonArray;
import com.sun.mail.util.MailSSLSocketFactory;

/**
 * 
 * @author @author Shaik Abdul Sharukh, Samhitha
 *
 */
public class MailAction
{
  private static final Logger logger = Logger.getLogger(MailAction.class.getName());
  final static String delAction = "delete";
  final static String markAsRead = "markasread";
  static Properties prop = new Properties();

  /**
   * Default constructor.
   *
   */
  public MailAction()
  {
    try
    {
      InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("logger.properties");
      LogManager.getLogManager().readConfiguration(inputStream);
      logger.info("Initializing logger");
    }
    catch (Exception e)
    {
      System.out.println("ERROR: While initializing logger");
      e.printStackTrace();
    }
  }

  /**
   * Method handling mail actions like delete, markasread depending upon a
   * threshold limit
   *
   */
  public static String mailAction(String host, String port, String username, String password,
      List<String> folder, String actionReq, ZonedDateTime dateCk,String serverTZ, String typeOfmails)
  {
    Folder mailFolder = null;
    Properties props = System.getProperties();
    MailSSLSocketFactory sf;
    String status = null;
    System.out.println("mail action");
    try
    {
      sf = new MailSSLSocketFactory();
      sf.setTrustAllHosts(true);
      props.put("mail.imap.ssl.trust", "*");
      props.put("mail.imap.ssl.socketFactory", sf);
    }
    catch (GeneralSecurityException e1)
    {
      e1.printStackTrace();
      logger.severe("Error Message :" + e1.getMessage());
      return "{ \"status\" : \"Error: error while connecting to mail\"}";
    }

    props.setProperty("mail.imap.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
    props.setProperty("mail.imap.socketFactory.fallback", "false");
    props.setProperty("mail.imap.port", port);
    props.setProperty("mail.imap.socketFactory.port", port);
    props.put("mail.imap.host", host);

    Session session = Session.getInstance(props, new javax.mail.Authenticator()
    {
      protected PasswordAuthentication getPasswordAuthentication()
      {
        return new PasswordAuthentication(username, password);
      }
    });
    // For logging into different accounts and check mails whether they are older
    // than N days.
    try
    {
      boolean delete=false;
      Store store = session.getStore("imap");
      int mailPort = Integer.parseInt(port);
      store.connect(host, mailPort, username, password);
      System.out.println("connected to mail");

       //Whether to delete emails (expunge) on folder close
      if (actionReq.equals(delAction))
      {
    	  delete=true;
      }
			/*
			 * mailFolder1 = store.getDefaultFolder().list();
			 * System.out.println("My mailFolder is--" + mailFolder1);
			 */
      for (int i = 0; i < folder.size(); i++)
      {
        String folderType = folder.get(i).toString();
        System.out.println(folder.get(i));

        folderType = folderType.replaceAll("\"", "");
        mailFolder = store.getFolder(folderType);
        mailFolder.open(Folder.READ_WRITE);
        int count = 0;
        logger.info("Total messages:" + mailFolder.getMessageCount());
        Message[] messages = mailFolder.getMessages();

        // Checking every mail whether it falls it under the threshold range
        for (Message message : messages)
        {
          logger.info("Mail date:" + message.getReceivedDate());
           // Get date from mail and convert to a zonedDateTime
          ZonedDateTime mailDate= DateUtils.getDateWithTZ(message.getReceivedDate(), serverTZ);
          logger.info("Mail action:" + actionReq);
          logger.info("Mail with TZ Date:" + mailDate );
          logger.info("Comparing (" + typeOfmails + ") \t Mail:" + mailDate + " with:" + dateCk );
         
          if (typeOfmails.equals("older"))
          {
            // if mail is before the threshold date
            if (mailDate.isBefore(dateCk))
            {
              logger.info("before match");
              count++;
              if (actionReq.equals(delAction))
              { 
                // Flags deleted = new Flags(Flags.Flag.DELETED);
                message.setFlag(Flags.Flag.DELETED, true);
                // mailFolder.setFlags(messages, deleted, true);
                System.out.println("mails deleted");
                status = "mails deleted";
                mailFolder.expunge();
              }
              else if (actionReq.equals(markAsRead))
              {
                message.setFlag(Flags.Flag.SEEN, true);
                System.out.println("marked as read");
                status = "mails marked as read";
              }
            }

            logger.info("Count of mails older than threshold:" + count);
          }
          else if (typeOfmails.equals("newer"))
          {   	
            // if mail is before the threshold date
            if (mailDate.isAfter(dateCk))
            {
              logger.info("after match");
              count++;
              if (actionReq.equals(delAction))
              {
                message.setFlag(Flags.Flag.DELETED, true);
                System.out.println("mails deleted");
                status = "mails deleted";
                mailFolder.expunge();
              }
              else if (actionReq.equals(markAsRead))
              {
                message.setFlag(Flags.Flag.SEEN, true);
                System.out.println("marked as read");
                status = "mails marked as read";
              }
            }

            logger.info("Count of mails newer than threshold:" + count);
          }
        }
      }
      logger.info("Closing folder");
      logger.info("Closing folder:" + mailFolder.getName());
      mailFolder.close(delete);
      store.close();
      logger.info("After close");
    }
    catch (MessagingException e)
    {
      System.out.println("Exception while connecting to server: " + e.getLocalizedMessage());
      e.printStackTrace();
      logger.severe("Error Message :" + e.getMessage());
      status = "mail action can't be performed";
    }
    logger.info("status after mailaction:" + status);
    return status;
  }
}
