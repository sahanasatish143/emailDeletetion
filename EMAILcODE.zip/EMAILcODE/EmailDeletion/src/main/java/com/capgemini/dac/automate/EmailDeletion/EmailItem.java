/*
 * Copyright (c) 2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.EmailDeletion;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author Shaik Abdul Sharukh, A Samhitha
 * 
 *         This class depicts the construction of EmailItem with respect to the
 *         field parameters
 */
public class EmailItem {
	String name = "";
	String password = "";
	String domain = "";
	String host = "";
	String port = "";
	String serverTimezone = "";
	Map<String, String> folderInfo = new HashMap<String, String>();

	public EmailItem(String name, Map<String, String> fieldMap) {
		this.name = name;
		this.password = fieldMap.get("password");
		this.domain = fieldMap.get("domain");
		this.host = fieldMap.get("host");
		this.port = fieldMap.get("port");
		this.serverTimezone = fieldMap.get("serverTimezone");
		if (!name.equals("MAIN")) {
			// System.out.println("count");
			setFolderInfo(fieldMap);
		}

	}

	/**
	 * This method depicts the setting of the folderInformation and the age into the
	 * map
	 * 
	 * @param fieldMap
	 */
	private void setFolderInfo(Map<String, String> fieldMap) {
		String folderStr = fieldMap.get("folders");
		// System.out.println("folders---"+folderStr);
		String[] folderArr = folderStr.split(",");
		String ageStr = fieldMap.get("age");
		String[] ageArr = ageStr.split(",");
		// TODO if agearr.length != folderArr.length return error to client
		for (int x = 0; x < folderArr.length; x++) {
			this.folderInfo.put(folderArr[x], ageArr[x]);
		}
		// System.out.println("folderInfo-"+folderInfo);

		/*
		 * for (String name : folderInfo.keySet()) { // search for value String url =
		 * folderInfo.get(name); // System.out.println("Key = " + name + ", Value = " +
		 * url); }
		 */

	}

	public String getName() {
		return name;
	}

	public String getPassword() {
		return password;
	}

	public String getDomain() {
		return domain;
	}

	public String getHost() {
		return host;
	}

	public String getPort() {
		return port;
	}

	public String getServerTimezone() {
		return serverTimezone;
	}

	public Map<String, String> getFolderInfo() {
		return folderInfo;
	}
	/*
	 * public static void main(String[] args) {
	 * 
	 * 
	 * }
	 */

}
