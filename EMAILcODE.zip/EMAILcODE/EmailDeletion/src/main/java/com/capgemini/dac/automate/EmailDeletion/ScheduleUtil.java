/*
 * Copyright (c) 2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.EmailDeletion;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.logging.ConsoleHandler;
import java.util.logging.Logger;

import javax.mail.MessagingException;

import com.capgemini.dac.automate.Util.DateUtils;

/**
 * 
 * @author Shaik Abdul Sharukh, A Samhitha
 * 
 * This class represents the Schedule action of the email purge.
 *
 */
public class ScheduleUtil
{
  private static final Logger logger = Logger.getLogger(ScheduleUtil.class.getName());
  final static String delAction = "delete";
  // added for scheduling
  private final static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

  /**
   * Default Constructor.Initializes attributes.
   */
  public ScheduleUtil()
  {
    Logger.getLogger(ScheduleUtil.class.getName());
    ConsoleHandler consoleHandler = new ConsoleHandler();
    logger.addHandler(consoleHandler);
    logger.info("Initialized logger to console.");
  }

  /**
   * This method is to schedule the email utility purge action. This is being
   * scheduled for every 15 seconds This method will call the mailAction method
   * inturn to invoke the mailbox
   * 
   * All the parameters which are required have been read from the configuration
   * file
   */
  public static void beepForAnHour()
  {
    final Runnable beeper = new Runnable()
    {
      public void run()
      {
        String fileName = "/home/dac/emailutility/config.ini";
        LoadConfig lc = new LoadConfig();
        Map<String, EmailItem> iniMap = null;
        try
        {
          iniMap = new HashMap<String, EmailItem>();
          iniMap = lc.load(fileName);
        }
        catch (IOException | MessagingException e)
        {
          logger.severe(e.getMessage());
          e.printStackTrace();
        }

        String host = null;
        String port = null;
        String serverTimezone = null;
        ZonedDateTime dateCk;
        try
        {
          EmailItem listOfItems = iniMap.get("MAIN");
          port = listOfItems.getPort();
          host = listOfItems.getHost();
          serverTimezone = listOfItems.getServerTimezone();
          iniMap.remove("MAIN");

          for (String section : iniMap.keySet())
          {
            // search for value
            EmailItem itemsList = iniMap.get(section);
            String username = itemsList.getDomain();
            String password = itemsList.getPassword();
            System.out.println("Key = " + section + ", Value = " + username + password);
            logger.info("Key = " + section + ", Value = " + username + password);
            Map<String, String> folders = itemsList.getFolderInfo();
            for (Map.Entry<String, String> folderEntry : folders.entrySet())
            {
              System.out.println("Key: " + folderEntry.getKey() + " & Value: " + folderEntry.getValue());
              logger.info("Key: " + folderEntry.getKey() + " & Value: " + folderEntry.getValue());
              List<String> listFolders = new ArrayList<String>();
              listFolders.add(folderEntry.getKey().toString());
              System.out.println("listing of folders--" + listFolders);
              String age = folderEntry.getValue().toString();
              System.out.println("age is--" + age);
              logger.info("age is--" + age);
              // converting the age to long as Localdate accepts long
              long ageLong = Long.parseLong(age);
              if (serverTimezone == null)
              {
                System.out.println(" Entered into the timezone if as timezone is not specified in config file..");
                LocalDate localDate = LocalDate.now().minusDays(ageLong);
                // default time zone
                ZoneId defaultZoneId = ZoneId.systemDefault();
                Date dateC = Date.from(localDate.atStartOfDay(defaultZoneId).toInstant());
                dateCk = ZonedDateTime.ofInstant(dateC.toInstant(), defaultZoneId);
                System.out.println(" dateck is---" + dateCk);
                logger.info(" dateck is---" + dateCk);
              }
              else
              {
                System.out.println("Entered into the timezone else as timezone is specified in config file..");
                LocalDate localDate = LocalDate.now().minusDays(ageLong);
                ZoneId defaultZoneId = ZoneId.systemDefault();
                Date date1 = Date.from(localDate.atStartOfDay(defaultZoneId).toInstant());
                dateCk = DateUtils.getDateWithTZ(date1, serverTimezone);
                logger.info(" dateck is---" + dateCk);
              }
              // passing actionReq, servertimezone, typeofmails as MailAction method needs
              // those
              String actionReq = delAction;
              // String serverTZ = "America/New_York";
              String typeOfmails = "older";
              try
              {
                logger.info("mailAction Method call Initiated::");
                // calling mailAction() method
                MailAction.mailAction(host, port, username, password, listFolders, actionReq, dateCk, serverTimezone,
                    typeOfmails);
              }
              catch (Exception e)
              {
                logger.severe(e.getMessage());
                e.printStackTrace();
              }
            }
          }
        }
        catch (Exception e)
        {
          logger.severe(e.getMessage());
          e.getMessage();
        }
      }
    };
    // scheduling for 15 seconds
    final ScheduledFuture<?> beeperHandle = scheduler.scheduleAtFixedRate(beeper, 15, 15, TimeUnit.SECONDS);
  }
}
