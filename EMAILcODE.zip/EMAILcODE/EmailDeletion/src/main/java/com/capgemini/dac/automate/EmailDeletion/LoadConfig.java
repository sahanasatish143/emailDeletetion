/*
 * Copyright (c) 2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */
package com.capgemini.dac.automate.EmailDeletion;

import java.io.File;
import java.io.IOException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.mail.MessagingException;

import org.ini4j.Ini;
import org.ini4j.InvalidFileFormatException;
import org.ini4j.Profile.Section;
/**
 * 
 *  @author Shaik Abdul Sharukh, A Samhitha
 *
 *  This class depicts the loading of config file(ini).
 * 
 *  
 *   
 *  
 */
public class LoadConfig
{
  Ini ini = null;
  static LoadConfig mySingleton = null;
  Map<String, EmailItem> iniToMap=null;

  /**
   * Default Constructor
   */
  public LoadConfig()
  {
  }
  

  
  /**
   * This method is to load the ini file which acts as a configuration.
   * @param fileName--specifies the file name
   * @return --returns iniToMap
   * @throws InvalidFileFormatException
   * @throws IOException
   * @throws MessagingException
   */
  
  public Map<String, EmailItem> load(String fileName) throws InvalidFileFormatException, IOException, MessagingException
  {
    // use .ini not wini because this will be running on Linux
    this.ini = new Ini(new File(fileName));
    iniToMap = LoadConfig.iniToMap(ini);
    return iniToMap;
  }
  
  
  public LoadConfig getInstance(String fileName) 
  {
    if (mySingleton == null)
    {
      mySingleton = new LoadConfig();
      try
      {
        mySingleton.load(fileName);
      }
      catch (IOException | MessagingException e)
      {
        e.printStackTrace();
      }
    }
    return mySingleton;
  }
  
 
 
 /**
  * 
  * This method is to get all the sections from config file and put them in a map
  * and use the map of section values to create an mail that contains the info
  * we need for an email account
  * @param ini
  * @return
  * @throws MessagingException
  */
  public static Map<String, EmailItem> iniToMap(Ini ini) throws MessagingException
  {
    Map<String, EmailItem> iniMap = new HashMap<String, EmailItem>();

    // iterate through each section (which is the account name)
    Iterator<String> sectionIt = ini.keySet().iterator();
    while (sectionIt.hasNext())
    {
      String sectionName = sectionIt.next();
      System.out.println("Got Section:" + sectionName);

      Section section = ini.get(sectionName);
      // iterate through section values
      // put them into a map. Use the map when getting the defaults
      // use the map to construct the EmailItem for the section

      Iterator<Entry<String, String>> childIt = section.entrySet().iterator();
      Map<String, String> sectionMap = new HashMap<String, String>();
      while (childIt.hasNext())
      {
        Entry<String, String> childEntry = childIt.next();
        sectionMap.put(childEntry.getKey(), childEntry.getValue());
      } // while children/section values

      Iterator<Entry<String, String>> sectionMapforMain = sectionMap.entrySet().iterator();
      // sectionMap = setDefaults(sectionMap);
      // use the map of section values to create an EmailItem that contains the info
      // we need for an email account
      EmailItem eitem = new EmailItem(sectionName, sectionMap);
      iniMap.put(sectionName, eitem);
      // System.out.println("hey"+iniMap);   
    }
    return iniMap;
  
  // while sections
  // map key of section value of EmailItem
  }
 /**
  * This method returns the Section
  * @param name
  * 
  */
    public Section get(String name)
  {
    return ini.get(name);
  }
  /**
   * This methods depicts the main function to call the SCHEDULE mechanism
   * 
   * @param args
   * @throws Exception
   */
  public static void main(String[] args) throws Exception
  {
   //Calling schedule method
   ScheduleUtil.beepForAnHour();
  }
}
