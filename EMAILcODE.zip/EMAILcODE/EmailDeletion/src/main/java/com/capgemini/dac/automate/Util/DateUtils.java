package com.capgemini.dac.automate.Util;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.logging.Logger;

public class DateUtils
{
	private static final Logger logger = Logger.getLogger(DateUtils.class.getName());
	public DateUtils()
	{
		
	}
	public static ZonedDateTime getDateWithTZ(Date inDate, String tzStr)
	{
	    ZoneId tz= ZoneId.of(tzStr);
		ZonedDateTime zdt = ZonedDateTime.ofInstant(inDate.toInstant(), tz);
		logger.info("getDateWithTZ:" + zdt.format(DateTimeFormatter.ISO_ZONED_DATE_TIME));
		return zdt;
	}
	
	public static ZonedDateTime convertTZ(String dateStr, String fromTZ, String toTZ)
	{
		ZonedDateTime convertedDateTime;
		 // convert string to LocalDateTime
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss");
		LocalDateTime ldt = LocalDateTime.parse(dateStr, formatter);
		logger.info("LDT:" + ldt);

		 // DateTimeFormatter format = DateTimeFormatter.ofPattern("MM/dd/yyyy - HH:mm:ss a Z");
		DateTimeFormatter format2 = DateTimeFormatter.ISO_ZONED_DATE_TIME;
		ZonedDateTime inDateTime = ldt.atZone(ZoneId.of(fromTZ));
		logger.info("Zone1:" + inDateTime.format(format2));

		convertedDateTime = inDateTime.withZoneSameInstant(ZoneId.of(toTZ));

		logger.info("Zone2:" + convertedDateTime.format(format2));
		return convertedDateTime;
	}

}
