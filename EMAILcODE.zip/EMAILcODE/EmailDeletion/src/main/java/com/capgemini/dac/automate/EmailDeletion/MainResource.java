/*
 * Copyright (c) 2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.EmailDeletion;

import java.io.InputStream;
import java.lang.reflect.Type;
import java.time.ZonedDateTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.ConsoleHandler;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.ini4j.Profile.Section;

import com.capgemini.dac.automate.Util.DateUtils;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

/**
 * This class represents the main resource for the web service. In where we
 * accept web request and we invoke the MailAction class to do the required
 * action (markasread and delete) the emails in specified folders.
 * 
 * @author Sharath Bala, Shaik Abdul Sharukh, Samhitha
 */
@Path("/mailaction")
public class MainResource
{
  private static final Logger logger = Logger.getLogger(MainResource.class.getName());
  //private static final String CONFIG_FILE="D:\\Users\\ashaik11\\repositories\\dacEmailMaintUtility\\config.ini";
  //private static final String CONFIG_FILE="D:\\temp\\test.ini";
  private static final String CONFIG_FILE="/home/dac/emailutility/config.ini";
  public LoadConfig loadConfig = new LoadConfig();
  static Map<String, String> sectionMap;
  static Properties prop = new Properties();

  /**
   * Default constructor. Initializes attributes.
   * 
   */
  public MainResource()
  {
    // Loading Configuration file
	  this.loadConfig = loadConfig.getInstance(CONFIG_FILE);
    // set JVM option -DDevelopment=true for development. Logs to console instead of
    // file
    String isDev = System.getProperty("Development");
    if (isDev != null)
    {
      System.out.println("Development mode. Logging to console");
      Logger.getLogger(MainResource.class.getName());
      ConsoleHandler consoleHandler = new ConsoleHandler();
      logger.addHandler(consoleHandler);
      logger.info("Initialized logger to console.");
    }
    else
    {
      try
      {
        // initialize logger
        InputStream inputStream = Thread.currentThread().getContextClassLoader()
            .getResourceAsStream("logger.properties");
        LogManager.getLogManager().readConfiguration(inputStream);
        logger.info("Initializing logger");
      }
      catch (Exception e)
      {
        logger.info("ERROR: While initializing logger");
        e.printStackTrace();
      }
    }
  }

  /**
   * Sample JSON
   * 
    {
    "account":"LAB",
    "reqAction":"markasread",
    "date":"09-15-2020 01:25:55",
    "timezone":"Asia/Kolkata",
    "type":"older",
    "folder":["INBOX","Junk"]
    }
    timezone is optional it will default to what is defined in the server config file
   */
  /**
   * Method handling HTTP POST requests that include JSON body which comes as
   * input.
   *
   * @param jsonBody--input request which
   * contains(account,reqaction,date,type,folder)
   * 
   * @account--specifes the account eg.automiclab,ccna etc.
   * @reqaction--specifie the the operation(delete or markasread)
   * @date--specifies the timestamp to delete or to make mails marasread
   * @type--specifies the type of mails(newer,older)
   * @folder--specifies the folder eg. INBOX, Junk etc.
   * @return status of the action mentioned in JSON format
   */
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public String email(String jsonBody)
  {
    String accountDetails = null;
    String actionRequired = null;
    String status = null;
    JsonElement folder = null;
    JsonArray folderArray = null;
    String typeOfmails = null;
    ZonedDateTime dateCkTZ;
    List<String> listfolder=null;
   Section acc = loadConfig.get("MAIN") ;
   String serverTZStr = acc.get("serverTimezone");
  
    //TZ the user used in their request (Server and request TZ can be the same) 
    String requestTZStr="America/New_York"; // Assume ET 
    // json parsing code
    try
    {
      JsonElement jelement = new JsonParser().parse(jsonBody);
      JsonObject jobject = jelement.getAsJsonObject();
      JsonElement jsonDate = jobject.get("date");
      String dateStr = jsonDate.getAsString();
      
         //get timezone string from JSON input
	  JsonElement jsonTZ = jobject.get("timezone");
	   
		 //get TZ from input if specified. Otherwise it will assume config server TZ
		if (jsonTZ != null)
		{
			  // get TZ as string
			requestTZStr = jsonTZ.getAsString();
		}
		
		try
		{
		    // Get a zoneddatetime converted from tz to tz.
	      dateCkTZ = DateUtils.convertTZ(dateStr,requestTZStr,serverTZStr);
		}
		catch (DateTimeParseException e)
		{
			 // error parsing date
			return "{ \"status\" : \"Error: parsing date value:" + dateStr +"\"}";
		}
	
      JsonElement account = jobject.get("account");
      logger.info("Account :" + account);
      folder = jobject.get("folder");
      logger.info("Folder :" + folder);
      JsonElement action = jobject.get("reqAction");
      logger.info("Action :" + action);
      JsonElement type = jobject.get("type");
      logger.info("type :" + type);

      if (account != null && folder != null && action != null)
      {
        accountDetails = account.getAsString();
        logger.info("AccountDetails :" + accountDetails);
        folderArray = folder.getAsJsonArray();
        System.out.println(folderArray);
        Type listType = new TypeToken<List<String>>() {}.getType();
        listfolder = new Gson().fromJson(folder, listType);
        actionRequired = action.getAsString();
        logger.info("ActionRequired :" + actionRequired);
        typeOfmails = type.getAsString();
        logger.info("typeOfmails :" + typeOfmails);
      }
      else
      {
        // return error if account not found
        return "{ \"status\" : \"Error: Incomplete/incorrect JSON payload. Expecting account parameters.\"}";
      }
    }
    catch (Exception e1)
    {
      e1.printStackTrace();
      logger.severe("ERROR: Error while fetching Json data");
      return "{ \"status\" : \"Error: error fetching json data\"}";
    }
    
    Section accDetails = loadConfig.get(accountDetails);
    System.out.println("My accDetails-" + accDetails);
    String host = acc.get("host");
    System.out.println(host);
    logger.info("Host: " + host);
    String port = acc.get("port");
    logger.info("Port:" + port);
    String domain = acc.get("domain");
    logger.info("Domain:" + domain);
    String logDir = acc.get("loggingDirectory");
    logger.info("LogDirectory:" + logDir);
    String purge = acc.get("runpurge");
    logger.info("runPurge:" + purge);

    String username = accDetails.get("domain");
    logger.info(username);
    String password = accDetails.get("password");
    logger.info(password);
    String age = accDetails.get("age");
    logger.info(age);

    // calling mail action
    status = MailAction.mailAction(host, port, username, password, listfolder, actionRequired,dateCkTZ ,serverTZStr,
        typeOfmails);
    System.out.println("mail action");
    logger.info("status :" + status);
    return "{ \"status\" : " + "\"" + status + "\"}";
  }
}